package Test10;

import java.io.*;


public class WritetoFile {
public static void main(String [] args) throws IOException {
	FileOutputStream fos = new FileOutputStream("./xyz.txt");
		String msg="Hello, How are you";
	byte[] arr=msg.getBytes();
	fos.write(arr);
	fos.close();
}
}
