package Revision;

import java.util.HashMap;

public class HashMapEg {
    public static void main(String[] args) {
        
        HashMap<String, Boolean> hm = new HashMap<>();
        
        
        hm.put("ggggg", true);
        hm.put("ggrerggg", true);
        hm.put("ggggg", true); 
        hm.put("dfdf", true);
        hm.put("ggggg", true); 
        hm.put("srsdfsdfs", true);
        hm.put("sdfsfereer", true);

        // Using forEach correctly to print keys
        hm.keySet().stream().forEach(key -> System.out.println(key));
    }
}