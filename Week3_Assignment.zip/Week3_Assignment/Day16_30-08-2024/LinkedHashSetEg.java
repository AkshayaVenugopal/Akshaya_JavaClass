package Revision;

import java.util.*;

public class LinkedHashSetEg {
    public static void main(String[] args) {
        LinkedHashSet<String> lhs = new LinkedHashSet<>();
        lhs.add("ggggg");
        lhs.add("ggrerggg");
        lhs.add("ggggg"); 
        lhs.add("dfdf");
        lhs.add("ggggg"); 
        lhs.add("srsdfsdfs");
        lhs.add("sdfsfereer");

        // Using forEach correctly
        lhs.stream().forEach(item -> System.out.println(item));
    }
}