package Test05;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class ChatMsgHM {

	public static void main(String [] args) {
		HashMap<String,String> hmss=new HashMap<>();
		hmss.put("name1", "msg99");
		hmss.put("name2", "msg199");
		hmss.put("name3", "msg299");
		hmss.put("name4", "msg399");
		hmss.put("name5", "msg499");
		hmss.put("name6", "msg599");
		Set<String> ss=hmss.keySet();
		for(String item_key:ss) {
			//System.out.println(item_key+"--->"+hmss.get(item_key));
		}
		
		 TreeMap<String, String> tmss = new TreeMap<>(Comparator.reverseOrder());

	        // Adding entries to the TreeMap
	        tmss.put("Name1", "Msg01");
	        tmss.put("Name2", "Msg02");
	        tmss.put("Name3", "Msg03");
	        tmss.put("Name4", "Msg04");
	        tmss.put("Name5", "Msg05");
	        tmss.put("Name6", "Msg06");
	        System.out.println("\nPrinting in treemap\n");

	        // Iterating over the TreeMap and printing the entries
	        for (Map.Entry<String, String> entry : tmss.entrySet()) {
	            System.out.println(entry.getKey() + " = " + entry.getValue());
	}

}
}

