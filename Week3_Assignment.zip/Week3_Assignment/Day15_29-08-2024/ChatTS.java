package Test05;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

class ChatEg {
    private String sender_name;
    private String msg;

    public ChatEg(String sender_name, String msg) {
        this.sender_name = sender_name;
        this.msg = msg;
    }

    public String getSender_name() {
        return sender_name;
    }

    public void setSender_name(String sender_name) {
        this.sender_name = sender_name;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "Chats [sender_name=" + sender_name + ", msg=" + msg + "]";
    }
}


public class ChatTS {

	public static void main(String[] args) {
        // Use lambda expression for Comparator
        Comparator<Chats> mcmp = (o1, o2) -> o1.getMsg().compareTo(o2.getMsg());

        // Initialize TreeSet with the lambda Comparator
        TreeSet<Chats> cmsgs = new TreeSet<>(mcmp);

        // Add messages to the TreeSet
        cmsgs.add(new Chats("name6", "msg1"));
        cmsgs.add(new Chats("name2", "msg2"));
        cmsgs.add(new Chats("name1", "msg3"));
        cmsgs.add(new Chats("name4", "msg4"));

        display(cmsgs);
        
        Chats c= Collections.min(cmsgs,(c1,c2)->c1.getMsg().compareTo(c2.getMsg()));
        cmsgs.stream().filter((e)->e.getSender_name().equalsIgnoreCase("name1"))
        .forEach((item)->{System.out.println(item);});
        System.out.println("----------------");
        System.out.println(c);
    }

    private static void display(TreeSet<Chats> cmsgs) {
		// TODO Auto-generated method stub
		
	}

	// Display method for List<Chats>
    static void display(List<Chats> cmsgs) {
        for (Chats cmg : cmsgs) {
            System.out.println(cmg);
        }
    }
}
