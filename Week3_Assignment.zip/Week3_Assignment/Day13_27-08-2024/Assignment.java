package Test03;

import java.util.Collections;
import java.util.TreeSet;

public class Assignment {
    public static void main(String[] args) {
        // Create a TreeSet with natural ordering
        TreeSet<String> cmsgs = new TreeSet<>();
        cmsgs.add("P13 - D");
        cmsgs.add("P2 - S");
        cmsgs.add("P9 - d");
        cmsgs.add("P8 - N");
        cmsgs.add("P13 - e");
        cmsgs.add("P5 - Y");
        cmsgs.add("P8 - I");
        cmsgs.add("P9 - completed");
        
        // Display all elements
        display(cmsgs);
        
        // Find and display the minimum and maximum elements
        System.out.println("Minimum element: " + cmsgs.first());
        System.out.println("Maximum element: " + cmsgs.last());
    }
    
    static void display(TreeSet<String> ts) {
        for (String str : ts) {
            System.out.println(str);
        }
    }
}
