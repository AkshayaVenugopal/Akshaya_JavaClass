package Test03;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class ChatMessage {

	public static void main(String [] args) {
		HashMap<String,String> hmss=new HashMap<>();
		hmss.put("Name1", "msg99");
		hmss.put("Name2", "msg199");
		hmss.put("Name3", "msg299");
		hmss.put("Name4", "msg399");
		hmss.put("Name5", "msg499");
		hmss.put("Name6", "msg599");
		Set<String> ss=hmss.keySet();
		for(String item_key:ss) {
			//System.out.println(item_key+"--->"+hmss.get(item_key));
		}
		
		 TreeMap<String, String> tmss = new TreeMap<>(Comparator.reverseOrder());

	        // Adding entries to the TreeMap
	        tmss.put("Name1", "msg99");
	        tmss.put("Name2", "msg199");
	        tmss.put("Name3", "msg299");
	        tmss.put("Name4", "msg399");
	        tmss.put("Name5", "msg499");
	        tmss.put("Name6", "msg599");
	        System.out.println("\nPrinting in treemap\n");

	        // Iterating over the TreeMap and printing the entries
	        for (Map.Entry<String, String> entry : tmss.entrySet()) {
	            System.out.println(entry.getKey() + " = " + entry.getValue());
	}

}
}

