package Test03;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

class Chats {
    private String sender_name;
    private String msg;
    
    public Chats(String sender_name, String msg) {
        this.sender_name = sender_name;
        this.msg = msg;
    }
    
    @Override
    public String toString() {
        return "Chats [sender_name=" + sender_name + ", msg=" + msg + "]";
    }
}


public class ChatMessageLinkedList {

	public static void main(String[] args) {
        List<Chats> msgs = new LinkedList<>();
        
        // Create Chats objects and add to the linked list
        msgs.add(new Chats("M1", "Hi"));
        msgs.add(new Chats("M2", "Yes"));
        msgs.add(new Chats("M3", "Super"));
        msgs.add(new Chats("M4", "Fine"));
        msgs.add(new Chats("M5", "Nice"));
        msgs.add(new Chats("M6", "Like"));
        msgs.add(new Chats("M7", "Bye"));
        msgs.add(new Chats("M8", "completed"));
        
        // Display the original list
        System.out.println("Original chat messages:");
        display(msgs);
        
        // Reverse the linked list
        reverseList(msgs);
        
        // Display the reversed list
        System.out.println("\nReversed chat messages:");
        display(msgs);
        
        // Reverse the list again to restore original order
        reverseList(msgs);
        
        // Display the restored list
        System.out.println("\nRestored original chat messages:");
        display(msgs);
    }
    
    // Method to display the list of Chats objects
    static void display(List<Chats> list) {
        for (Chats chat : list) {
            System.out.println(chat);
        }
    }
    
    // Method to reverse the linked list
    static void reverseList(List<Chats> list) {
        LinkedList<Chats> reversedList = new LinkedList<>();
        
        // Iterate over the original list and add elements to the reversed list
        ListIterator<Chats> iterator = list.listIterator(list.size());
        while (iterator.hasPrevious()) {
            reversedList.add(iterator.previous());
        }
        
        // Clear the original list and add all elements from the reversed list
        list.clear();
        list.addAll(reversedList);
    }
}

