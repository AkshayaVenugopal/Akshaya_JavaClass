package Test01;

public class ArrayDiagonals {
	
	public static void main(String[] args) {
	    int[][] array = {
	      {5, 2, 3, 45},  // Row 0
	      {5, 3, 9, 8},  // Row 1
	      {9, 17, 12, 4},  // Row 2
	      {18, 14, 15, 20}  // Row 3
	    };

	    int primaryDiagonalSum = 0;  // Initialize sum for primary diagonal
	    int secondaryDiagonalSum = 0;  // Initialize sum for secondary diagonal

	    for (int i = 0; i < array.length; i++) {
	      // Add element to primary diagonal sum (row index == column index)
	      primaryDiagonalSum += array[i][i];
	      
	      // Add element to secondary diagonal sum (row index == column index mirrored)
	      secondaryDiagonalSum += array[i][array.length - i - 1];
	    }

	    System.out.println("Primary Diagonal Sum: " + primaryDiagonalSum);
	    System.out.println("Secondary Diagonal Sum: " + secondaryDiagonalSum);
	  }
	}


