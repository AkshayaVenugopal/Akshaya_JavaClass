package Test04;

import Test02.PermanentEmployee;
import Test03.TemporaryEmployee;

public class MainProgram {
public static void main(String[] args) {
	PermanentEmployee pobj = new PermanentEmployee (567, "Lavanya", 234.6f, "Main Street");
	
	pobj.displayp();
	
	//create object of Temporary Employee and call display() method.
	TemporaryEmployee ptemp = new TemporaryEmployee (212, "Rajii", 95.67f, "Rose Street");
	ptemp.display();
}
}