package Test03;

import Test02.Employee;

public class TemporaryEmployee extends Employee{
	private float hourlypay;
	private String company_addr;

	public TemporaryEmployee(int id, String name, float hourlypay, String company_addr) {
		super(id, name);
		this.hourlypay = hourlypay;
		this.company_addr = company_addr;
	}
	
	public void display() {
		displaye();
		System.out.println("Hourly Pay is " + hourlypay + " and Company address is " +company_addr);
	}

}

