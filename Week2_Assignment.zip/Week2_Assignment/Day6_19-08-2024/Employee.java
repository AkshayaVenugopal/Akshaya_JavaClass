package Test02;

public class Employee {
private int id;
private String name;

Employee(){
	System.out.println("Employee()");
}

protected Employee(int id, String name){
	this.id = id;
	this.name = name;
}

public int getEid() {
	//Employee obj = new Employee();
	//obj = null;
	return id;
}

public void setEid(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
public void displaye() {
	System.out.println("Employee id: " + id+" name: " + name );
}
}
