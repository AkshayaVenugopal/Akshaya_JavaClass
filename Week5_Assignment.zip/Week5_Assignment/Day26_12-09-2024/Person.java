package com.junit.Eg;

import java.util.Objects;

public class Person {
	private String name;
	private int age;
	private float loan_eligibility;

	
	public Person(String name, int age, float loan_eligibility) {
		super();
		this.name = name;
		this.age = age;
		this.loan_eligibility = loan_eligibility;
	}

	public float getLoan_eligibility() {
		return loan_eligibility;
	}

	public void setLoan_eligibility(float loan_eligibility) {
		this.loan_eligibility = loan_eligibility;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}