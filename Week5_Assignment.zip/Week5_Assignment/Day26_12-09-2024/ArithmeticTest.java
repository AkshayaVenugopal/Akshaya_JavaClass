package com.junit.Check;

import org.junit.jupiter.api.Test;

import com.junit.Eg.Arithmetic;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ArithmeticTest {

    private  Arithmetic arithmetic ;
    

    @BeforeAll
    static void befallmet() {
    System.out.println("Before All method");	
    }
    
    @BeforeEach
    void befeachmet() {
    arithmetic = new Arithmetic();	
    System.out.println("Before Each method");
    	
    }
    @Order(1)
    @Tag("Feature1")
    @Test //Testcase
    void testMet() {
    	Arithmetic arith = new Arithmetic();
    	System.out.println("Test 1");
    	
    	//invoke business logic method with certain parameters
    	int actual_val = arith.add(-3,-5);
    	
    	assertEquals(-8, actual_val, "Addition should work for negative values also");
    	//crosscheck return value with expected value using assert
    	
    }
    
  
    @Order(2)
    @Tag("Feature2")
    @Test
    void testAdd() {
    	System.out.println("Test 2");
        assertEquals(5, arithmetic.add(2, 3), "Addition should return the sum of two numbers");
    }

    @Order(3)
    @Tag("Feature1")
    @Test
    void testSubtract() {
    	System.out.println("Test 3");
        assertEquals(1, arithmetic.subtract(5, 4), "Subtraction should return the difference of two numbers");
    }

    @Test
    @Tag("Feature1")
    void testMultiply() {
        assertEquals(6, arithmetic.multiply(2, 3), "Multiplication should return the product of two numbers");
    }

    @Test
    @Tag("Feature2")
    void testDivide() {
        assertEquals(2, arithmetic.divide(6, 3), "Division should return the quotient of two numbers");
    }

    @Test
    @Tag("Feature1")
    void testDivideByZero() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> arithmetic.divide(1, 0), "Division by zero should throw ArithmeticException");
        assertEquals("Cannot divide by zero", thrown.getMessage());
      }
    
   
}
