package com.mockitoEg;

public interface UserRepository {
    User findById(Long id);
}

