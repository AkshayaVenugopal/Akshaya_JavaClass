package com.exampledb.demo_ticket.RepositoryLayer;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.exampledb.demo_ticket.model.Ticket;

@Repository
//JPARepository
   public interface TicketRepository extends JpaRepository<Ticket, Integer> { 

//CrudRepository	
	//public interface TicketRepository extends CrudRepository<Ticket, Integer> { 

//PagingAndSortingRepository
	//public interface TicketRepository extends PagingAndSortingRepository<Ticket, Integer> { 
	//Get all tickets with a specific from place and to place
	public List<Ticket> findByFromplaceOrToplace(String from_place, String to_place);
	
	//Get all tickets From Place and To Place, price less than
	public List<Ticket> findByFromplaceAndToplaceAndPriceLessThan(String from_place, String to_place, float price);
	
	//JPQL
	@Query("SELECT w FROM Ticket w WHERE w.fromplace = :fromplace")
	List<Ticket> met(@Param("fromplace") String str);
	
	//SQL
	@Query(value = "SELECT * FROM ticket where username = :uname", nativeQuery = true)
	List<Ticket> met9(@Param("uname") String username);
	
	@Modifying
	@Transactional
	@Query("UPDATE Ticket t set t.price = t.price*0.9 WHERE t.username = :uname") 
	void met10(@Param("uname") String username);
	
	

}

