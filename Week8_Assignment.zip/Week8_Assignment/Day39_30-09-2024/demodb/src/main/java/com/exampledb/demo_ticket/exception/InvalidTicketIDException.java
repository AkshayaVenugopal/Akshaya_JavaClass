package com.exampledb.demo_ticket.exception;

public class InvalidTicketIDException extends RuntimeException {
	public InvalidTicketIDException(String message) {
		super(message);
	}

}
