package com.exampledb.demo_ticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.exampledb.demo_ticket","com.controller"})
public class DemodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemodbApplication.class, args);
	}

}
