package com.exampledb.demo_ticket.Servicelayer;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.exampledb.demo_ticket.model.Ticket;
import com.exampledb.demo_ticket.RepositoryLayer.TicketRepository;

@Service
public class TicketService {

@Autowired
private TicketRepository ticketRepo;
//Dependency Injection

public Ticket getTicketServ (int ticketid) {
Optional<Ticket> oticket = ticketRepo.findById(ticketid);

//ticketRepo.findByFromplaceAndToplace(" ", " ");

return oticket.get();
}

public Ticket bookTicketServ (Ticket ticket) {
return ticketRepo.save(ticket);
}

public Ticket updateTicketServ (int tid, Ticket ticket) {
	Ticket eTicket = ticketRepo.findById(tid).get();
	eTicket.setFrom_place(ticket.getFrom_place());
	eTicket.setTo_place(ticket.getTo_place());
	eTicket.setPrice(ticket.getPrice());
	
return ticketRepo.save(eTicket);
}

public Ticket cancelTicketRepo (int ticketid) {
Ticket ticket = ticketRepo.findById(ticketid).get();
ticketRepo.deleteById(ticketid);
return ticket;
}
/*
//New method to search tickets by fromPlace and toPlace
public List<Ticket> searchTicketsServ(String fromPlace, String toPlace) {
 return ticketRepo.searchTicketsRepo(fromPlace, toPlace);
}

*/
}


