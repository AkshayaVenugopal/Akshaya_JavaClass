package Test01;

public class Factorial_usingMethod {

	public static void main(String[] args)
	{	
//Factorial
	
	int num=7;
	System.out.println("Factorial of " +num +" is "+factorial(num));
}
	public static int factorial(int num) {
		int fact =1;
		for (int i =1; i<= num; i++){
			fact*=i;
		}
		return fact;
		}
	
}
