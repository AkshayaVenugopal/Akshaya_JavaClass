package Test01;

public class ReverseDigit {
	public static void main(String[] args) {
		int num = 6814, reversed = 0;
		System.out.println("Reversed digits:");
		
		while (num!=0){
			int digit = num%10;
		reversed = reversed * 10 + digit;
		num/=10;
		
		
		// print each digit one by one
	System.out.println(digit);
	}
	}
}

