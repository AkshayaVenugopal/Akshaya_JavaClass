package Test01;

public class Average_Array {
	public static void main(String[] args) {
		//declare and initialize array with petrol prices
	
		double[] petrolprice= {89.11,78.97,82.34,83.9,90.03,80};
		
		//Initialize a variable to store the total sum of prices
       double sum = 0;
       
       //loop through each price in the array
       for(double price : petrolprice){
    	   
    	   //Add the current price to the total price
    	   sum += price;
    	   }
       
       //calculate the average petrol price by dividing the sum by the number of prices
       double average = sum/petrolprice.length;
       
       //prining the average price
       System.out.println("Average Petrol Price is : " + average);
}
}
